package temp;

public class Vaccine {
	private String name;
	private int no_of_shots;
	private int elligible_age;
	private boolean booster_required;
	private boolean additionl_dose;
	
	
	public Vaccine(String name, int no_of_shots, int elligible_age, boolean booster_required, boolean additionl_dose) {
		super();
		this.name = name;
		this.no_of_shots = no_of_shots;
		this.elligible_age = elligible_age;
		this.booster_required = booster_required;
		this.additionl_dose = additionl_dose;
	}
	
	
	@Override
	public String toString() {
		return "Vaccine [name=" + name + ", no_of_shots=" + no_of_shots + ", elligible_age=" + elligible_age
				+ ", booster_required=" + booster_required + ", additionl_dose=" + additionl_dose + "]";
	}

	public String display(){
		return name+" "+no_of_shots+" "+elligible_age+" "+(booster_required?"Booster Needed":"No Booster Needed");
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getNo_of_shots() {
		return no_of_shots;
	}
	public void setNo_of_shots(int no_of_shots) {
		this.no_of_shots = no_of_shots;
	}
	public int getElligible_age() {
		return elligible_age;
	}
	public void setElligible_age(int elligible_age) {
		this.elligible_age = elligible_age;
	}
	public boolean isBooster_required() {
		return booster_required;
	}
	public void setBooster_required(boolean booster_required) {
		this.booster_required = booster_required;
	}
	public boolean isAdditionl_dose() {
		return additionl_dose;
	}
	public void setAdditionl_dose(boolean additionl_dose) {
		this.additionl_dose = additionl_dose;
	}
	
	
	

}
