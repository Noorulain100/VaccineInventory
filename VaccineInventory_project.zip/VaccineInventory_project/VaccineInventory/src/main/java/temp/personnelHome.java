package temp;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class personnelHome extends JFrame {

	private JPanel contentPane;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					
					
					personnelHome frame = new personnelHome();
					frame.setVisible(true);
					
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}


	public personnelHome() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 746, 529);
		contentPane = new JPanel();
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Personnel of the Committee - Dashboard");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 28));
		lblNewLabel.setBounds(87, 10, 585, 53);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("Edit People");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				personelInterface frame = new personelInterface();
				frame.setVisible(true);
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton.setBounds(250, 240, 150, 50);
		contentPane.add(btnNewButton);
		
		JButton btnVaccines = new JButton("Vaccines");
		btnVaccines.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				VaccineInterface frame = new VaccineInterface();
				frame.setVisible(true);
			}
		});
		btnVaccines.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnVaccines.setBounds(250, 300, 150, 50);
		contentPane.add(btnVaccines);
	}
}
