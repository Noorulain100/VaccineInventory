package temp;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class displayPeople extends JFrame {

	private JPanel contentPane;
	private JTable table_1;

	/**
	 * Launch the application.
     * @param args
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(() -> {
                    try {
                        displayPeople frame = new displayPeople();
                        frame.setVisible(true);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });
	}
public static void ShowData(JTable table , ArrayList<People> records) {         
		
		DefaultTableModel model = new DefaultTableModel();   // CREATING A TABLE MODEL THAT WILL TRANSFER OUR DATA
                                                                    // FROM ARRAYLIST TO TABLE
		Object[] columnsName = new Object[10];
		columnsName[0] = "FirstName";
		columnsName[1] = "LastName";
		columnsName[2] = "Age";
		columnsName[3] = "Gender";
		columnsName[4] = "CNIC"; 
		columnsName[5] = "DOB";
		columnsName[6] = "Key";
		columnsName[7] = "Appointment Status";
		columnsName[8] = "Vaccination Status";
		columnsName[9] = "City";
		

		model.setColumnIdentifiers(columnsName); // ADDING COLUMNSNAME INTO TABLE

		Object[] rowdata = new Object[10];
		

		for (int i = 0; i < records.size(); i++) {
			
			rowdata[0] = records.get(i).getfname();
			rowdata[1] = records.get(i).getlname();
			rowdata[2] = records.get(i).getAge();										      
			rowdata[3] = records.get(i).getGender();
			rowdata[4] = records.get(i).getCNIC();
			rowdata[5] = records.get(i).getdateOfBirth();
			rowdata[6] = records.get(i).getpassword();
			rowdata[7] = records.get(i).isAppointmentSet();
			rowdata[8] = records.get(i).isVaccinated();
			rowdata[9] = records.get(i).getCity();
			

			model.addRow(rowdata); // ADDING ALL THE ROWS INTO THE TABLE MODEL
			
		}
		
		table.setModel(model);
		
	}
	
	
	
	
	

	/**
	 * Create the frame.
	 */
	public displayPeople() {
		
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 578, 454);
		contentPane = new JPanel();
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 86, 544, 321);
		contentPane.add(scrollPane);
		
		table_1 = new JTable();
		scrollPane.setViewportView(table_1);
		
		JButton btnNewButton = new JButton("Show Data");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Driver.showAllPersons(Driver.persons);
				
				ShowData(table_1, Driver.persons);
			}
		});
		btnNewButton.setBounds(166, 10, 205, 47);
		contentPane.add(btnNewButton);
		
		
	}
}
