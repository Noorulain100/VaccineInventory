package temp;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Random;

import javax.swing.*;

public class personelInterface extends JFrame {

	private JPanel contentPane;
	private JTextField txtFirstName;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	
	JRadioButton rdbtnNewRadioButton = new JRadioButton("Male");
	private JTextField textField_4;
	private JTextField textField_5;
	boolean personON = false;
	public static int found_index = 0;
	public static String generated_key;
	
	public static int index_to_confirm;
	
	JLabel lblNewLabel_3 ;

	public static void main(String[] args) {
		EventQueue.invokeLater(() -> {
                    try {
                        personelInterface frame = new personelInterface();
                        frame.setVisible(true);
                        
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });
	}
	public static String genPassword() {
		String key = "";
		Random random = new Random();
		
		for(int i=0; i<4; i++) {
			key += random.nextInt(9);
		}
		
		return key;
	}

	public personelInterface() {
		try {
			Driver.read(Driver.persons);
			
			
		} catch (FileNotFoundException e2) {
			
			e2.printStackTrace();
		}
		
		
		setTitle("Covid-19 Vaccination System");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1040, 552);
		contentPane = new JPanel();
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		JLabel lblNewLabel = new JLabel("People Dashboard");
                lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel.setBounds(136, 10, 293, 56);
		contentPane.add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.lightGray);
		panel.setBounds(543, 83, 427, 417);
		contentPane.add(panel);
		panel.setLayout(null);
		
		txtFirstName = new JTextField();
		txtFirstName.setFont(new Font("Tahoma", Font.PLAIN, 13));
		txtFirstName.setBounds(22, 93, 140, 26);
		panel.add(txtFirstName);
		txtFirstName.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Register People");
		lblNewLabel_1.setBounds(129, 10, 175, 35);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Fisrt Name");
		lblNewLabel_2.setBounds(22, 70, 83, 13);
		panel.add(lblNewLabel_2);
		
		textField = new JTextField();
		textField.setFont(new Font("Tahoma", Font.PLAIN, 13));
		textField.setColumns(10);
		textField.setBounds(224, 93, 140, 26);
		panel.add(textField);
		
		JLabel lblNewLabel_2_1 = new JLabel("Last Name");
		lblNewLabel_2_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_2_1.setBounds(221, 64, 83, 13);
		panel.add(lblNewLabel_2_1);
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("Tahoma", Font.PLAIN, 13));
		textField_1.setColumns(10);
		textField_1.setBounds(22, 156, 140, 26);
		panel.add(textField_1);
		
		JLabel lblNewLabel_2_2 = new JLabel("CNIC");
		lblNewLabel_2_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_2_2.setBounds(22, 133, 83, 13);
		panel.add(lblNewLabel_2_2);
		
		textField_2 = new JTextField();
		textField_2.setFont(new Font("Tahoma", Font.PLAIN, 13));
		textField_2.setColumns(10);
		textField_2.setBounds(224, 156, 140, 26);
		panel.add(textField_2);
		
		JRadioButton male = new JRadioButton("M");
		male.setBounds(22, 258, 56, 21);
		panel.add(male);
		
		JRadioButton female = new JRadioButton("F");
		female.setBounds(94, 258, 56, 21);
		panel.add(female);
		
		
		ButtonGroup G = new ButtonGroup();
		G.add(male);
		G.add(female);
	
		
		JLabel lblNewLabel_2_2_1 = new JLabel("City");
		lblNewLabel_2_2_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_2_2_1.setBounds(221, 135, 83, 13);
		panel.add(lblNewLabel_2_2_1);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBackground(Color.WHITE);
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"}));
		comboBox.setToolTipText("");
		comboBox.setBounds(85, 306, 46, 21);
		panel.add(comboBox);
		
		JLabel lblNewLabel_2_2_2 = new JLabel("DOB");
		lblNewLabel_2_2_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_2_2_2.setBounds(22, 308, 34, 13);
		panel.add(lblNewLabel_2_2_2);
		
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setBackground(Color.WHITE);
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"Jan", "Feb", "March", "April", "May", "June", "July", "Aug", "Sept", "Oct", "Nov", "Dec"}));
		comboBox_1.setToolTipText("");
		comboBox_1.setBounds(141, 306, 56, 21);
		panel.add(comboBox_1);
		
		JComboBox comboBox_2 = new JComboBox();
		comboBox_2.setBackground(Color.WHITE);
		comboBox_2.setModel(new DefaultComboBoxModel(new String[] {"1990", "1991", "1992", "1993", "1994", "1995", "1996", "1997", "1998", "1999", "2000", "2001", "2002", "2003"}));
		comboBox_2.setToolTipText("");
		comboBox_2.setBounds(221, 306, 67, 21);
		panel.add(comboBox_2);
		
		JLabel lblNewLabel_2_2_2_1 = new JLabel("Gender");
		lblNewLabel_2_2_2_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_2_2_2_1.setBounds(24, 222, 64, 13);
		panel.add(lblNewLabel_2_2_2_1);
		
		textField_4 = new JTextField();
		textField_4.setFont(new Font("Tahoma", Font.PLAIN, 13));
		textField_4.setColumns(10);
		textField_4.setBounds(267, 218, 64, 21);
		panel.add(textField_4);
		
		JLabel lblNewLabel_2_2_2_1_1 = new JLabel("Age");
		lblNewLabel_2_2_2_1_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_2_2_2_1_1.setBounds(224, 215, 64, 26);
		panel.add(lblNewLabel_2_2_2_1_1);
		
		lblNewLabel_3 = new JLabel("Registered people:");
		lblNewLabel_3.setBounds(497, 31, 165, 26);
		contentPane.add(lblNewLabel_3);
		lblNewLabel_3.setForeground(Color.BLUE);
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_3.setText("Registered people: "+Driver.persons.size());
                
		JLabel vacc_label = new JLabel("Vaccinated people: 0");
		vacc_label.setForeground(Color.BLUE);
		vacc_label.setFont(new Font("Tahoma", Font.BOLD, 15));
		vacc_label.setBounds(672, 31, 165, 26);
		contentPane.add(vacc_label);
		
		JLabel appt_label = new JLabel("Appointments: 0");
		appt_label.setForeground(Color.BLUE);
		appt_label.setFont(new Font("Tahoma", Font.BOLD, 15));
		appt_label.setBounds(864, 31, 129, 26);
		contentPane.add(appt_label);
		
		
		JButton btnNewButton = new JButton("Submit");
		btnNewButton.setForeground(Color.WHITE);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				String fname = txtFirstName.getText(); 
				
				
				String lname = textField.getText(); 
				
				
				String cnic = textField_1.getText();
				
				
				String city = textField_2.getText();
				
				String gender = " ";
				
				if(male.isSelected()) {
					gender = "male";
				}
				else if(female.isSelected()) {
					gender = "female";
				}
				
				
			
				String age = textField_4.getText();
				
				
				
				String date = (String) comboBox.getSelectedItem();
				String month = (String) comboBox_1.getSelectedItem();
				String year = (String) comboBox_2.getSelectedItem();
				
				String dob = date+"/"+month+"/"+year;
				String pass = genPassword();
				
				Driver.persons.add(new People(fname, lname, dob, cnic, city, age, gender, false, false, pass ));
				
				
			    JOptionPane.showMessageDialog(new JFrame(),"Your Key: "+ pass);  

				
				Driver.showAllPersons(Driver.persons);
				
				try {
					Driver.insert(Driver.persons);
				} catch (IOException e1) {
				
					e1.printStackTrace();
				}
				
				lblNewLabel_3.setText("Registered People: "+Driver.persons.size());
				
				
				int vacc_people= 0;
				int appt_people = 0;
				
				for(int i=0; i<Driver.persons.size(); i++) {
					if(Driver.persons.get(i).isAppointmentSet()) {
						appt_people++;
						vacc_people++;
					}
					
					
				}
				
				
				vacc_label.setText("Vaccinated: "+ vacc_people);
				appt_label.setText("Appointments: "+ appt_people);
				
				
				
				
			}
		});
		btnNewButton.setBackground(new Color(30, 144, 255));
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnNewButton.setBounds(22, 357, 113, 35);
		btnNewButton.setBorderPainted(false);
		panel.add(btnNewButton);
		
		JButton btnReset = new JButton("Reset");
		btnReset.setForeground(Color.WHITE);
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				textField.setText("");
				textField_1.setText("");
				textField_2.setText("");
				
				textField_4.setText("");
				txtFirstName.setText("");
				
				
			}
		});
		btnReset.setBackground(new Color(0, 0, 0));
		btnReset.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnReset.setBounds(271, 357, 122, 35);
		btnReset.setBorderPainted(false);

		panel.add(btnReset);
		
		
		
		JLabel lblNewLabel_2_1_1 = new JLabel("Search with Key");
		lblNewLabel_2_1_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_2_1_1.setBounds(10, 83, 139, 25);
		contentPane.add(lblNewLabel_2_1_1);
		
		textField_5 = new JTextField();
		textField_5.setFont(new Font("Tahoma", Font.PLAIN, 13));
		textField_5.setColumns(10);
		textField_5.setBounds(10, 117, 140, 26);
		contentPane.add(textField_5);
		
		JButton login = new JButton("Search");

		login.setForeground(Color.WHITE);
		login.setFont(new Font("Tahoma", Font.PLAIN, 15));
		login.setBackground(new Color(0, 191, 255));
		login.setBounds(180, 94, 112, 49);
		contentPane.add(login);
		
		
		
		
		JButton btnModify = new JButton("Modify Record");
		btnModify.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				editDetails m = new editDetails();
				m.setVisible(true);
				
			}
		});
		btnModify.setForeground(Color.WHITE);
		btnModify.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnModify.setBorderPainted(false);
		btnModify.setBackground(Color.LIGHT_GRAY);
		btnModify.setBounds(156, 409, 129, 38);
		contentPane.add(btnModify);
		
		JLabel sname = new JLabel("Name");
		sname.setFont(new Font("Tahoma", Font.PLAIN, 15));
		sname.setBounds(43, 213, 199, 26);
		sname.setVisible(false);

		contentPane.add(sname);
		
		JLabel sage = new JLabel("Age");
		sage.setFont(new Font("Tahoma", Font.PLAIN, 15));
		sage.setBounds(43, 249, 139, 21);
		sage.setVisible(false);

		contentPane.add(sage);
		
		JLabel scnin = new JLabel("CNIC");
		scnin.setFont(new Font("Tahoma", Font.PLAIN, 15));
		scnin.setBounds(43, 280, 199, 13);
		scnin.setVisible(false);

		contentPane.add(scnin);
		
		JLabel scity = new JLabel("City");
		scity.setFont(new Font("Tahoma", Font.PLAIN, 15));
		scity.setBounds(43, 303, 205, 21);
		scity.setVisible(false);

		contentPane.add(scity);
		
		JLabel sdob = new JLabel("DOB");
		sdob.setFont(new Font("Tahoma", Font.PLAIN, 15));
		sdob.setBounds(43, 334, 205, 25);
		sdob.setVisible(false);

		contentPane.add(sdob);
		
		JLabel sgender = new JLabel("Gender");
		sgender.setFont(new Font("Tahoma", Font.PLAIN, 15));
		sgender.setBounds(43, 356, 205, 25);
		sgender.setVisible(false);

		contentPane.add(sgender);
		
		JLabel personNotFound = new JLabel("Person Not Found");
		personNotFound.setForeground(Color.RED);
		personNotFound.setBackground(Color.WHITE);
		personNotFound.setFont(new Font("Tahoma", Font.BOLD, 15));
		personNotFound.setBounds(95, 177, 165, 26);
		personNotFound.setVisible(false);
		contentPane.add(personNotFound);
		
		JButton btnDeleteRecord = new JButton("Delete Record");
		btnDeleteRecord.setForeground(Color.WHITE);
		btnDeleteRecord.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnDeleteRecord.setBorderPainted(false);
		btnDeleteRecord.setBackground(Color.RED);
		btnDeleteRecord.setBounds(156, 462, 129, 38);
		contentPane.add(btnDeleteRecord);
		
		
		JLabel label_appointment = new JLabel("Appointment set: ");
		label_appointment.setFont(new Font("Tahoma", Font.BOLD, 13));
		label_appointment.setBounds(280, 220, 179, 27);
		label_appointment.setVisible(false);
		contentPane.add(label_appointment);
		
		JLabel label_vacc = new JLabel("Vaccinated");
		label_vacc.setFont(new Font("Tahoma", Font.BOLD, 13));
		label_vacc.setBounds(280, 247, 179, 27);
		label_vacc.setVisible(false);
		contentPane.add(label_vacc);
		
		
		login.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Driver.showAllPersons(Driver.persons);

				personNotFound.setVisible(false);
				sname.setVisible(false);
				sage.setVisible(false);
				scnin.setVisible(false);
				scity.setVisible(false);
				sdob.setVisible(false);
				sgender.setVisible(false);
				label_appointment.setVisible(false);
				label_vacc.setVisible(false);

				String to_search = textField_5.getText();
				
				
				boolean isFound = false;
				
				for(int i=0; i<Driver.persons.size(); i++) {
					if(Driver.persons.get(i).getpassword().equals(to_search)) {
						found_index = i;
						isFound = true;
						break;
						
					}
				}
				
				if(isFound) {
					
					personON = true;
					
					sname.setText("Name: "+ Driver.persons.get(found_index).getfname()+" "+Driver.persons.get(found_index).getlname());
					sage.setText("Age: "+Driver.persons.get(found_index).getAge());
					scnin.setText("CNIC: "+Driver.persons.get(found_index).getCNIC());
					scity.setText("City: "+ Driver.persons.get(found_index).getCity());
					sdob.setText("DOB: "+ Driver.persons.get(found_index).getdateOfBirth());
					sgender.setText("Gender: "+ Driver.persons.get(found_index).getGender());
					
					sname.setVisible(true);
					sage.setVisible(true);
					scnin.setVisible(true);
					scity.setVisible(true);
					sdob.setVisible(true);
					sgender.setVisible(true);
					
					String appt_status = "Appointment Status: ";
					String vacc_status = "Vaccination Status: ";
					
					if(Driver.persons.get(found_index).isAppointmentSet()) {
						appt_status += "TRUE";
						vacc_status += "TRUE";
					}else {
						appt_status += "FALSE";
						vacc_status += "FALSE";
					}
					
					
					label_vacc.setText(vacc_status);
					label_vacc.setVisible(true);
					
					label_appointment.setText(appt_status);
					label_appointment.setVisible(true);
					

				}
				else {
					personNotFound.setVisible(true);
				}
				
				
			}
		});
		
		btnDeleteRecord.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!personON) {
				    JOptionPane.showMessageDialog(new JFrame(),"Select a Record to Delete.");  

					
				}else {
					
					Driver.persons.remove(found_index);
					try {
						Driver.insert(Driver.persons);
					} catch (IOException e1) {
						
						e1.printStackTrace();
					}
					
				    JOptionPane.showMessageDialog(new JFrame(),"Record Deleted.");  
				    personNotFound.setVisible(false);
					sname.setVisible(false);
					sage.setVisible(false);
					scnin.setVisible(false);
					scity.setVisible(false);
					sdob.setVisible(false);
					sgender.setVisible(false);
					label_appointment.setVisible(false);
					label_vacc.setVisible(false);


				}
				
			}
		});
		
		
		JButton btnSetAppointment = new JButton("Set Appointment");
		btnSetAppointment.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String searchIndex = textField_5.getText();
				int ind = 0;
				
				
				
				for(int i=0; i<Driver.persons.size(); i++) {
					if(Driver.persons.get(i).getpassword().equals(searchIndex)) {
						ind = i;
						break;
						
					}
				}
				
				Driver.persons.get(ind).setAppointmentSet(true);
				index_to_confirm = ind;
				
				
				try {
					Driver.insert(Driver.persons);
				} catch (IOException e1) {
					
					e1.printStackTrace();
				}
				
				
				
				int vacc_people= 0;
				int appt_people = 0;
				
				for(int i=0; i<Driver.persons.size(); i++) {
					if(Driver.persons.get(i).isAppointmentSet()) {
						appt_people++;
						vacc_people++;
					}
					
					
				}
				
				
				vacc_label.setText("Vaccinated: "+ vacc_people);
				appt_label.setText("Appointments: "+ appt_people);
				
				JOptionPane.showMessageDialog(new JFrame(),"Appointment and Vaccination Status Set.");  
				
			}
		});
		btnSetAppointment.setForeground(Color.WHITE);
		btnSetAppointment.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnSetAppointment.setBorderPainted(false);
		btnSetAppointment.setBackground(Color.ORANGE);
		btnSetAppointment.setBounds(10, 462, 136, 38);
		contentPane.add(btnSetAppointment);
		
		JSeparator separator_2_2 = new JSeparator();
		separator_2_2.setForeground(Color.GRAY);
		separator_2_2.setBounds(60, 165, 381, 13);
		contentPane.add(separator_2_2);
		
		JButton btnRemoveAppointment = new JButton("Remove Appointment");
		btnRemoveAppointment.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String searchIndex = textField_5.getText();
				int ind = 0;
				for(int i=0; i<Driver.persons.size(); i++) {
					if(Driver.persons.get(i).getpassword().equals(searchIndex)) {
						ind = i;
						break;
					}
				}
				
				Driver.persons.get(ind).setAppointmentSet(false);
				
				
				try {
					Driver.insert(Driver.persons);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				
				
				
				int vacc_people= 0;
				int appt_people = 0;
				
				for(int i=0; i<Driver.persons.size(); i++) {
					if(Driver.persons.get(i).isAppointmentSet()) {
						appt_people++;
						vacc_people++;
					}
					
					
				}
				
				
				vacc_label.setText("Vaccinated: "+ vacc_people);
				appt_label.setText("Appointments: "+ appt_people);
				JOptionPane.showMessageDialog(new JFrame(),"Appointment and Vaccination Status Removed.");  
				
				
			}
		});
		btnRemoveAppointment.setForeground(Color.BLACK);
		btnRemoveAppointment.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnRemoveAppointment.setBorderPainted(false);
		btnRemoveAppointment.setBackground(Color.LIGHT_GRAY);
		btnRemoveAppointment.setBounds(10, 409, 136, 38);
		contentPane.add(btnRemoveAppointment);
		
                
		JButton btnShowAllPeople = new JButton("Show All People");
		btnShowAllPeople.addActionListener((ActionEvent e) -> {
                    displayPeople frame = new displayPeople();
                    frame.setVisible(true);
                });
		btnShowAllPeople.setForeground(Color.WHITE);
		btnShowAllPeople.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnShowAllPeople.setBorderPainted(false);
		btnShowAllPeople.setBackground(new Color(218, 112, 214));
		btnShowAllPeople.setBounds(317, 94, 179, 49);
		contentPane.add(btnShowAllPeople);
		
                
		JButton btnConfirmVaccination = new JButton("Confirm Vaccination");
		btnConfirmVaccination.addActionListener((ActionEvent e) -> {
                    Driver.persons.get(index_to_confirm).setVaccinated(false);
                    JOptionPane.showMessageDialog(new JFrame(),"Vaccination Confirmed.");  

                });
		btnConfirmVaccination.setForeground(Color.WHITE);
		btnConfirmVaccination.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnConfirmVaccination.setBackground(new Color(128, 0, 128));
		btnConfirmVaccination.setBounds(312, 430, 184, 38);
		contentPane.add(btnConfirmVaccination);
	}
}
