package temp;

public class People {
	private String fname;
	private String lname;
	private String dateOfBirth;
	private String CNIC;
	
	private String city;
	private String age;
	private String gender;
	
	
	private String password;
	
	
	public String getpassword() {
		return password;
	}

	public void setpassword(String password) {
		this.password = password;
	}

	private boolean appointmentSet;
	private boolean vaccinated;
	
	public boolean isAppointmentSet() {
		return appointmentSet;
	}

	public void setAppointmentSet(boolean appointmentSet) {
		this.appointmentSet = appointmentSet;
	}

	public boolean isVaccinated() {
		return vaccinated;
	}

	public void setVaccinated(boolean vaccinated) {
		this.vaccinated = vaccinated;
	}

	public People(String fname, String lname, String dateOfBirth, String cNIC, String city, String age, String gender, boolean appointmentSet, boolean vaccinated, String password) {
		
		this.fname = fname;
		this.lname = lname;
		this.dateOfBirth = dateOfBirth;
		CNIC = cNIC;
		this.city = city;
		this.age = age;
		this.gender = gender;
		this.appointmentSet= appointmentSet;
		this.vaccinated = vaccinated;
		this.password = password;
	}

	public String getfname() {
		return fname;
	}

	public void setfname(String fname) {
		this.fname = fname;
	}

	public String getlname() {
		return lname;
	}

	public void setlname(String lname) {
		this.lname = lname;
	}

	public String getdateOfBirth() {
		return dateOfBirth;
	}

	public void setdateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getCNIC() {
		return CNIC;
	}

	public void setCNIC(String cNIC) {
		CNIC = cNIC;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	
	
	
}
