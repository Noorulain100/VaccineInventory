package temp;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.awt.event.ActionEvent;

public class editDetails extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					editDetails frame = new editDetails();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}


	public editDetails() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 574, 463);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(new Color(32, 178, 170));
		panel.setBounds(0, 10, 560, 426);
		contentPane.add(panel);
		
		textField = new JTextField();
		textField.setFont(new Font("Tahoma", Font.PLAIN, 13));
		textField.setColumns(10);
		textField.setBounds(144, 75, 140, 26);
		panel.add(textField);
		
		JLabel lblNewLabel_1 = new JLabel("Modify the Information here");
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1.setBackground(Color.DARK_GRAY);
		lblNewLabel_1.setBounds(22, 22, 319, 35);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Fisrt Name");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_2.setBounds(22, 81, 83, 13);
		panel.add(lblNewLabel_2);
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("Tahoma", Font.PLAIN, 13));
		textField_1.setColumns(10);
		textField_1.setBounds(144, 124, 140, 26);
		panel.add(textField_1);
		
		JLabel lblNewLabel_2_1 = new JLabel("Last Name");
		lblNewLabel_2_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_2_1.setBounds(22, 130, 83, 13);
		panel.add(lblNewLabel_2_1);
		
		textField_2 = new JTextField();
		textField_2.setFont(new Font("Tahoma", Font.PLAIN, 13));
		textField_2.setColumns(10);
		textField_2.setBounds(388, 75, 140, 26);
		panel.add(textField_2);
		
		JLabel lblNewLabel_2_2 = new JLabel("CNIC");
		lblNewLabel_2_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_2_2.setBounds(327, 81, 64, 13);
		panel.add(lblNewLabel_2_2);
		
		textField_3 = new JTextField();
		textField_3.setFont(new Font("Tahoma", Font.PLAIN, 13));
		textField_3.setColumns(10);
		textField_3.setBounds(388, 124, 140, 26);
		panel.add(textField_3);
		
		JLabel lblNewLabel_2_2_1 = new JLabel("City");
		lblNewLabel_2_2_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_2_2_1.setBounds(327, 130, 56, 13);
		panel.add(lblNewLabel_2_2_1);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"}));

		comboBox.setToolTipText("");
		comboBox.setBackground(Color.WHITE);
		comboBox.setBounds(268, 220, 34, 21);
		panel.add(comboBox);
		
		JLabel lblNewLabel_2_2_2 = new JLabel("Date of Birth:");
		lblNewLabel_2_2_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_2_2_2.setBounds(22, 222, 127, 19);
		panel.add(lblNewLabel_2_2_2);
		
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"Jan", "Feb", "March", "April", "May", "June", "July", "Aug", "Sept", "Oct", "Nov", "Dec"}));

		comboBox_1.setToolTipText("");
		comboBox_1.setBackground(Color.WHITE);
		comboBox_1.setBounds(320, 220, 45, 21);
		panel.add(comboBox_1);
		
		JComboBox comboBox_2 = new JComboBox();
		comboBox_2.setModel(new DefaultComboBoxModel(new String[] {"1990", "1991", "1992", "1993", "1994", "1995", "1996", "1997", "1998", "1999", "2000", "2001", "2002", "2003"}));

		comboBox_2.setToolTipText("");
		comboBox_2.setBackground(Color.WHITE);
		comboBox_2.setBounds(195, 220, 56, 21);
		panel.add(comboBox_2);
		
		JLabel lblNewLabel_2_2_2_1 = new JLabel("Gender");
		lblNewLabel_2_2_2_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_2_2_2_1.setBounds(22, 298, 64, 26);
		panel.add(lblNewLabel_2_2_2_1);
		
		textField_4 = new JTextField();
		textField_4.setFont(new Font("Tahoma", Font.PLAIN, 13));
		textField_4.setColumns(10);
		textField_4.setBounds(144, 301, 88, 21);
		panel.add(textField_4);
		
		textField_5 = new JTextField();
		textField_5.setFont(new Font("Tahoma", Font.PLAIN, 13));
		textField_5.setColumns(10);
		textField_5.setBounds(401, 301, 64, 21);
		panel.add(textField_5);
		
		JLabel lblNewLabel_2_2_2_1_1 = new JLabel("Age");
		lblNewLabel_2_2_2_1_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_2_2_2_1_1.setBounds(327, 301, 64, 17);
		panel.add(lblNewLabel_2_2_2_1_1);
		
		JButton btnNewButton = new JButton("Proceed");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String fname = textField.getText(); 
				
				
				String lname = textField_1.getText(); 
				
				
				String cnic = textField_2.getText();
				
				String city = textField_3.getText();
				
				String gender = textField_4.getText();
			
				
				String age = textField_5.getText();
				
				
				
				String date = (String) comboBox.getSelectedItem();
				String month = (String) comboBox_1.getSelectedItem();
				String year = (String) comboBox_2.getSelectedItem();
				
				String dob = date+"/"+month+"/"+year;
				
				
				Driver.persons.get(personelInterface.found_index).setfname(fname);
				Driver.persons.get(personelInterface.found_index).setlname(lname);
				Driver.persons.get(personelInterface.found_index).setCNIC(cnic);
				Driver.persons.get(personelInterface.found_index).setCity(city);
				Driver.persons.get(personelInterface.found_index).setGender(gender);
				Driver.persons.get(personelInterface.found_index).setAge(age);
				Driver.persons.get(personelInterface.found_index).setdateOfBirth(dob);
				
				
			    JOptionPane.showMessageDialog(new JFrame(),"Information Updated!");  

				try {
					Driver.insert(Driver.persons);
				} catch (IOException e1) {
					
					e1.printStackTrace();
				}
			}
		});
		btnNewButton.setForeground(Color.WHITE);
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnNewButton.setBorderPainted(false);
		btnNewButton.setBackground(new Color(0, 191, 255));
		btnNewButton.setBounds(220, 353, 121, 43);
		panel.add(btnNewButton);
	}

}
