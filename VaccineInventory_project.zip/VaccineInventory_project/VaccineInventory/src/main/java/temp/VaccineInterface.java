package temp;

import java.awt.*;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.IOException;
import java.util.ArrayList;

public class VaccineInterface extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	
	private int c1, c2, c3, c4 = 0;
	

	
	JPanel panel_1;
	private ArrayList<Vaccine> vaccineList = new ArrayList<>();

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VaccineInterface frame = new VaccineInterface();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}


	public VaccineInterface() {
		vaccineList.add(new Vaccine("pfizer",0,21,false,false));
		vaccineList.add(new Vaccine("moderna",0,18,false,false));
		vaccineList.add(new Vaccine("janssen",0,22,false,false));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1055, 533);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBackground(new Color(0, 128, 128));
		panel_1.setBounds(617, 166, 351, 301);
		contentPane.add(panel_1);
		
		panel_1.setVisible(false);
		
		JLabel lblNewLabel = new JLabel("Vaccines - Dashboard");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 30));
		lblNewLabel.setBounds(349, 10, 364, 67);
		contentPane.add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(192, 192, 192));
		panel.setBounds(39, 142, 402, 325);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_2 = new JLabel("ADD VACCINES");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_2.setBounds(127, 36, 159, 27);
		panel.add(lblNewLabel_2);
		
		textField = new JTextField();
		textField.setFont(new Font("Tahoma", Font.BOLD, 15));
		textField.setBounds(227, 182, 135, 32);
		panel.add(textField);
		textField.setColumns(10);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setFont(new Font("Tahoma", Font.BOLD, 12));
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Centre 1", "Centre 2", "Centre 3"}));
		comboBox.setForeground(new Color(0, 0, 0));
		comboBox.setBackground(Color.WHITE);
		comboBox.setBounds(227, 112, 89, 21);
		panel.add(comboBox);
		
		JLabel lblNewLabel_3 = new JLabel("Select the Centre: ");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_3.setBounds(21, 115, 186, 18);
		panel.add(lblNewLabel_3);
		
		JLabel lblNewLabel_3_1 = new JLabel("Number of Vaccines: ");
		lblNewLabel_3_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_3_1.setBounds(21, 188, 186, 18);
		panel.add(lblNewLabel_3_1);
		

		

		
		JLabel lblNewLabel_2_1 = new JLabel("AVAILABLE VACCINES");
		lblNewLabel_2_1.setForeground(Color.WHITE);
		lblNewLabel_2_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_2_1.setBounds(52, 23, 250, 27);
		panel_1.add(lblNewLabel_2_1);
		
		JLabel pfizer_label = new JLabel("Centre 1: ");
		pfizer_label.setForeground(Color.WHITE);
		pfizer_label.setFont(new Font("Tahoma", Font.BOLD, 20));
		pfizer_label.setBounds(103, 140, 186, 27);
		panel_1.add(pfizer_label);
		
		JLabel moderna_label = new JLabel("Centre 2: ");
		moderna_label.setForeground(Color.WHITE);
		moderna_label.setFont(new Font("Tahoma", Font.BOLD, 20));
		moderna_label.setBounds(103, 182, 186, 27);
		panel_1.add(moderna_label);
		
		JLabel janssen_label = new JLabel("Center 3: ");
		janssen_label.setForeground(Color.WHITE);
		janssen_label.setFont(new Font("Tahoma", Font.BOLD, 20));
		janssen_label.setBounds(103, 226, 186, 27);
		panel_1.add(janssen_label);
		

		
		JLabel lblNewLabel_1 = new JLabel("Vaccines Available: ");
		lblNewLabel_1.setBounds(103, 60, 171, 32);
		panel_1.add(lblNewLabel_1);
		lblNewLabel_1.setForeground(Color.BLACK);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		
		JButton btnNewButton_1 = new JButton("SHOW ALL VACCINES");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				panel_1.setVisible(false);
				
				pfizer_label.setText("Centre 1: "+ c1);
				moderna_label.setText("Centre 2: "+ c2);
				janssen_label.setText("Centre 3: "+ c3);
				
				
				panel_1.setVisible(true);
				
				
			}
		});
		btnNewButton_1.setForeground(Color.WHITE);
		btnNewButton_1.setBackground(new Color(65, 105, 225));
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_1.setBounds(674, 109, 218, 47);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton = new JButton("Proceed");
		btnNewButton.addActionListener((ActionEvent e) -> {
                    int value = comboBox.getSelectedIndex();
                    
                    switch (value) {
                        case 0:
                            c1 += Integer.parseInt(textField.getText());
                            vaccineList.get(0).setNo_of_shots(c1);
                            break;
                        case 1:
                            c2 += Integer.parseInt(textField.getText());
                            vaccineList.get(1).setNo_of_shots(c2);
                            break;
                        case 2:
                            c3 += Integer.parseInt(textField.getText());
                            vaccineList.get(2).setNo_of_shots(c3);
                            break;
                        case 3:
                            c4 += Integer.parseInt(textField.getText());
                            break;
                        default:
                            break;
                    }
                    
                    try {
                        Driver.insertVaccine(vaccineList);
                    } catch (IOException ioException) {
                        ioException.printStackTrace();
                    }
                    
                    JOptionPane.showMessageDialog(new JFrame(),"Vaccine Added Success.");
                });
		btnNewButton.setBackground(new Color(0, 191, 255));
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton.setBounds(135, 265, 122, 39);
		panel.add(btnNewButton);
	}
}
