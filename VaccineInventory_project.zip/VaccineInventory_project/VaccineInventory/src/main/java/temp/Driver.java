/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package temp;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author HP
 */
public class Driver {

  static ArrayList<People> persons = new ArrayList<>();
    static int no_stored_peoples;

    public static void main(String[] args) throws FileNotFoundException {

        read(persons);

    }

    public static void showAllPersons(ArrayList<People> peoples) {
        for (int i = 0; i < peoples.size(); i++) {

            System.out.println(peoples.get(i).toString());
        }
    }

    public static void insert(ArrayList<People> peoples) throws IOException {
        FileWriter pen = new FileWriter("records.txt");

        for (int i = 0; i < peoples.size(); i++) {
            String txt_line = peoples.get(i).getfname() + "-" + peoples.get(i).getlname() + "-" + peoples.get(i).getCNIC() + "-"
                    + peoples.get(i).getdateOfBirth() + "-" + peoples.get(i).getGender() + "-" + peoples.get(i).getCity() + "-" 
                    + peoples.get(i).getAge() + "-" + peoples.get(i).isAppointmentSet()+ "-" + peoples.get(i).isVaccinated()
                    + "-" + peoples.get(i).getpassword() + "\n";
            pen.write(txt_line);
        }

        pen.close();
    }

    public static void insertVaccine(ArrayList<Vaccine> vaccines) throws IOException {
        FileWriter pen = new FileWriter("vaccine.txt");

        for (int i = 0; i < vaccines.size(); i++) {
            Vaccine vaccine = vaccines.get(i);
            String txt_line = vaccine.getName()+","+vaccine.getElligible_age()+","+vaccine.getNo_of_shots()+","
                    +vaccine.isAdditionl_dose()+","+vaccine.isBooster_required()+"\n";
            pen.write(txt_line);
        }

        pen.close();
    }

    public static ArrayList<Vaccine> readVaccines() throws FileNotFoundException {
        File file = new File("../VaccineInventory/vaccine.txt");
        Scanner scan_read = new Scanner(file);
        ArrayList<Vaccine> vaccines = new ArrayList<>();
        while (scan_read.hasNext()) {
            String row = scan_read.nextLine();
            String[] info = row.split(",");
            Vaccine vaccine = new Vaccine(info[0],Integer.parseInt(info[2]),Integer.parseInt(info[1])
                    ,Boolean.parseBoolean(info[4]),Boolean.parseBoolean(info[3]));
            vaccines.add(vaccine);
        }
        return vaccines;
    }

    public static void read(ArrayList<People> peoples) throws FileNotFoundException {
        File file = new File("records.txt");
        Scanner scan_read = new Scanner(file);

        while (scan_read.hasNext()) {
            String row = scan_read.nextLine();
            String[] info = row.split("-");

            peoples.add(new People(info[0], info[1], info[3],
                    info[2], info[5], info[6], info[4],
                    Boolean.parseBoolean(info[7]), Boolean.parseBoolean(info[8]),
                    info[9]));
            no_stored_peoples++;
        }
    }
}